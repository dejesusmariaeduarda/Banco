package Banco;

class ContaNormal extends Conta {
    // Classe específica para ContaNormal, que usa os métodos e atributos de Conta
}
